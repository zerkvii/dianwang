#/bin/ash

cd /mnt/local
killall sge800app
chmod +x sge800check
chmod +x check_start.sh

sleep 5

if [ -f "/mnt/local/start.bak" ]; then
	echo "start.sh has already backed." > /dev/console
else
	echo "check starting, wait for reboot." > /dev/console
	mv start.sh start.bak
	cp check_start.sh start.sh
	chmod +x start.sh
	
	reboot
fi