#!/bin/ash

#VERSION=1.0

export LD_LIBRARY_PATH=.:/mnt/local/lib

#ιһ�¹�
/mnt/local/sge800-watchdog-feed-inter
/bin/echo "sge800-watchdog-feed-inter"

/bin/echo "local.sh V1.0-jzq"

cd /mnt/local
#/bin/echo "press Crtl-c stop program"

#�����ϵ续�棬-j��ʾ��������-f��ʾ����
chmod +x poweron_display
./poweron_display -j

/bin/echo "Config network"
/sbin/ifconfig eth0 hw ether 00:05:69:00:00:01
/sbin/ifconfig eth0 192.168.10.65 up

/bin/echo "Start telnet server"
/sbin/telnetd

#��������������
/bin/echo "**************************************************************************************"
/bin/echo "***********************************start Loading driver*******************************"
/bin/echo "**************************************************************************************"
/bin/echo " "

cd /mnt/local
/sbin/insmod /mnt/local/driver/mcu.ko
/sbin/insmod /mnt/local/driver/atmel_tc.ko
/sbin/insmod /mnt/local/driver/atmel_powerd.ko
/sbin/insmod /mnt/local/driver/atmel_ps.ko
/sbin/insmod /mnt/local/driver/rtc_driver.ko
/sbin/insmod /mnt/local/driver/spi_esam.ko

/bin/echo " "
/bin/echo "**************************************************************************************"
/bin/echo "**********************************Loading driver over*********************************"
/bin/echo "**************************************************************************************"


/bin/echo "mount /mnt/data0"

if [ -c /dev/mtd4 ]; then    
   /bin/mount -t yaffs /dev/mtdblock4 /mnt/data0
else
   /bin/mount -t yaffs /dev/mtdblock2 /mnt/data0
fi 

#/bin/echo "mount /mnt/sdcard"
#/bin/mount -t vfat /dev/mmcblk0p1 /mnt/sddisk

#/bin/echo "mount /mnt/nfs"
#/bin/mount -t nfs -o nolock 192.168.2.100:/cygdrive/f/workspace /mnt/nfs
