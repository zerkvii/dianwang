#!/bin/sh
#VERSION=1.0 �޸����ڣ�180604���ܣ�������������ݿ�Ŀ¼���з�������

if [ ! -d /mnt/data0/oopeam ]; then
   mkdir /mnt/data0/oopeam
fi

if [ ! -d /mnt/data0/oopeam/data ]; then
   mkdir /mnt/data0/oopeam/data
fi

if [ ! -d /mnt/data0/oopeam/event ]; then
   mkdir /mnt/data0/oopeam/event
fi

if [ ! -d /mnt/data0/oopeam/data/0 ]; then
   mkdir /mnt/data0/oopeam/data/0
fi

if [ ! -d /mnt/data0/oopeam/data/1 ]; then
   mkdir /mnt/data0/oopeam/data/1
fi

if [ ! -d /mnt/data0/oopeam/data/2 ]; then
   mkdir /mnt/data0/oopeam/data/2
fi

if [ ! -d /mnt/data0/oopeam/data/3 ]; then
   mkdir /mnt/data0/oopeam/data/3
fi

if [ ! -d /mnt/data0/oopeam/data/4 ]; then
   mkdir /mnt/data0/oopeam/data/4
fi

if [ ! -d /mnt/data0/oopeam/data/5 ]; then
   mkdir /mnt/data0/oopeam/data/5
fi

if [ ! -d /mnt/data0/oopeam/data/6 ]; then
   mkdir /mnt/data0/oopeam/data/6
fi

if [ ! -d /mnt/data0/oopeam/data/7 ]; then
   mkdir /mnt/data0/oopeam/data/7
fi

if [ ! -d /mnt/data0/oopeam/data/8 ]; then
   mkdir /mnt/data0/oopeam/data/8
fi

if [ ! -d /mnt/data0/oopeam/data/9 ]; then
   mkdir /mnt/data0/oopeam/data/9
fi


if [ ! -d /mnt/data0/oopeam/event/0 ]; then
   mkdir /mnt/data0/oopeam/event/0
fi

if [ ! -d /mnt/data0/oopeam/event/1 ]; then
   mkdir /mnt/data0/oopeam/event/1
fi

if [ ! -d /mnt/data0/oopeam/event/2 ]; then
   mkdir /mnt/data0/oopeam/event/2
fi

if [ ! -d /mnt/data0/oopeam/event/3 ]; then
   mkdir /mnt/data0/oopeam/event/3
fi

if [ ! -d /mnt/data0/oopeam/event/4 ]; then
   mkdir /mnt/data0/oopeam/event/4
fi

if [ ! -d /mnt/data0/oopeam/event/5 ]; then
   mkdir /mnt/data0/oopeam/event/5
fi

if [ ! -d /mnt/data0/oopeam/event/6 ]; then
   mkdir /mnt/data0/oopeam/event/6
fi

if [ ! -d /mnt/data0/oopeam/event/7 ]; then
   mkdir /mnt/data0/oopeam/event/7
fi

if [ ! -d /mnt/data0/oopeam/event/8 ]; then
   mkdir /mnt/data0/oopeam/event/8
fi

if [ ! -d /mnt/data0/oopeam/event/9 ]; then
   mkdir /mnt/data0/oopeam/event/9
fi

mv -f  /mnt/data0/oopeam/data/D???????????0*  /mnt/data0/oopeam/data/0/
mv -f  /mnt/data0/oopeam/data/D???????????1*  /mnt/data0/oopeam/data/1/
mv -f  /mnt/data0/oopeam/data/D???????????2*  /mnt/data0/oopeam/data/2/
mv -f  /mnt/data0/oopeam/data/D???????????3*  /mnt/data0/oopeam/data/3/
mv -f  /mnt/data0/oopeam/data/D???????????4*  /mnt/data0/oopeam/data/4/
mv -f  /mnt/data0/oopeam/data/D???????????5*  /mnt/data0/oopeam/data/5/
mv -f  /mnt/data0/oopeam/data/D???????????6*  /mnt/data0/oopeam/data/6/
mv -f  /mnt/data0/oopeam/data/D???????????7*  /mnt/data0/oopeam/data/7/
mv -f  /mnt/data0/oopeam/data/D???????????8*  /mnt/data0/oopeam/data/8/
mv -f  /mnt/data0/oopeam/data/D???????????9*  /mnt/data0/oopeam/data/9/

rm -rf /mnt/data0/oopeam/data/E*

#������¼��������������Ѿ���Ч�����¼����ݿ�ӿڸ��ģ�������Ҫ����¼���¼��
# ����ֳ���ȷҪ��������¼����ݣ������޸ĵײ����ݽӿڣ������ε���һ��ɾ���¼����ݴ���

mv -f  /mnt/data0/oopeam/data/E???????????0*  /mnt/data0/oopeam/event/0/
mv -f  /mnt/data0/oopeam/data/E???????????1*  /mnt/data0/oopeam/event/1/
mv -f  /mnt/data0/oopeam/data/E???????????2*  /mnt/data0/oopeam/event/2/
mv -f  /mnt/data0/oopeam/data/E???????????3*  /mnt/data0/oopeam/event/3/
mv -f  /mnt/data0/oopeam/data/E???????????4*  /mnt/data0/oopeam/event/4/
mv -f  /mnt/data0/oopeam/data/E???????????5*  /mnt/data0/oopeam/event/5/
mv -f  /mnt/data0/oopeam/data/E???????????6*  /mnt/data0/oopeam/event/6/
mv -f  /mnt/data0/oopeam/data/E???????????7*  /mnt/data0/oopeam/event/7/
mv -f  /mnt/data0/oopeam/data/E???????????8*  /mnt/data0/oopeam/event/8/
mv -f  /mnt/data0/oopeam/data/E???????????9*  /mnt/data0/oopeam/event/9/