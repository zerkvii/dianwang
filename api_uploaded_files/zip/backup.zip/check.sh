#/bin/ash

#VERSION=2.0 �޸����ڣ�20180612 �������д����echo�����

echo "start check.sh." > /dev/console

cd /mnt/local
echo "cd /mnt/local." > /dev/console

killall sge800app
echo "killall sge800app." > /dev/console

chmod +x sge800check
chmod +x check_start.sh
echo "chmod +x sge800check & check_start.sh." > /dev/console

sleep 5
echo "sleep 5." > /dev/console

if [ -f "/mnt/local/start.bak" ]; then
	echo "start.sh has already backed." > /dev/console
else
	echo "check starting, wait for reboot." > /dev/console
	mv start.sh start.bak
	echo "mv start.sh start.bak." > /dev/console

	cp check_start.sh start.sh
	echo "cp check_start.sh start.sh." > /dev/console

	chmod +x start.sh
	echo "chmod +x start.sh." > /dev/console
	
	echo "start reboot." > /dev/console
	reboot
fi